<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ATGuser;

class ATGController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'pincode' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:6|max:6'
        ]);
        $posts = ATGuser::where('email', $request->email)->get();
        if (count($posts) > 0) {
            return redirect('')->with('error', 'Email already Exist');
        } else {
            $atguser = new ATGuser();
            $atguser->name = $request->input('name');
            $atguser->email = $request->input('email');
            $atguser->pincode = $request->input('pincode');
            $atguser->save();
            return redirect('')->with('success', 'Data Stored');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
