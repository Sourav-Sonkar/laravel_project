<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{asset('css/app.css')}}">
        <title>{{config('app.name','ATG Project')}}</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
    </head>
    <body>
        @include('navbar')
        <hr>
        <div class="container">
            @include('message')
            {!! Form::open(['action'=> 'ATGController@store','method'=>'POST']) !!}
            <div class ="form-group">
                {{Form::label('name','Name')}}
                {{Form::text('name',"",['class'=>'form-control','placeholder'=>'Name'])}}
            </div>
            <div class ="form-group">
                {{Form::label('email','Email')}}
                {{Form::text('email',"",['class'=>'form-control','placeholder'=>'email@abc.com'])}}
            </div>
            <div class ="form-group">
                {{Form::label('pincode','Pincode')}}
                {{Form::text('pincode',"",['class'=>'form-control','placeholder'=>'eg.133001'])}}
            </div>
            
            {{Form::submit('Submit',['class'=>'btn btn-primary'])}}
        {!! Form::close() !!}
    
        </div>
        </body>
</html>
