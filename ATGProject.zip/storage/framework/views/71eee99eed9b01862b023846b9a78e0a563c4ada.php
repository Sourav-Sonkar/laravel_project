<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <title><?php echo e(config('app.name','ATG Project')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
    </head>
    <body>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <hr>
        <div class="container">
            <?php echo $__env->make('message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::open(['action'=> 'ATGController@store','method'=>'POST']); ?>

            <div class ="form-group">
                <?php echo e(Form::label('name','Name')); ?>

                <?php echo e(Form::text('name',"",['class'=>'form-control','placeholder'=>'Name'])); ?>

            </div>
            <div class ="form-group">
                <?php echo e(Form::label('email','Email')); ?>

                <?php echo e(Form::text('email',"",['class'=>'form-control','placeholder'=>'email@abc.com'])); ?>

            </div>
            <div class ="form-group">
                <?php echo e(Form::label('pincode','Pincode')); ?>

                <?php echo e(Form::text('pincode',"",['class'=>'form-control','placeholder'=>'eg.133001'])); ?>

            </div>
            
            <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    
        </div>
        </body>
</html>
<?php /**PATH F:\XAMPP\htdocs\ATGproject\resources\views/pages/index.blade.php ENDPATH**/ ?>